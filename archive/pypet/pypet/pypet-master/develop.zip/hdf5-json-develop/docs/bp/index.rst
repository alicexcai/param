Recommendations and Best Practices
==================================
