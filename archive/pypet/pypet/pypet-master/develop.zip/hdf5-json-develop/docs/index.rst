
HDF5/JSON
=========

Specification and tools for representing HDF5 in JSON

Contents:

.. toctree::
   :maxdepth: 2

   Installation/index
   Utilities
   bnf/index
   examples/index
    
