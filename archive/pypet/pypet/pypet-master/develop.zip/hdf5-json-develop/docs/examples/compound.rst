An HDF5 Compound Datatype
=========================

.. literalinclude:: compound.json
   :language: javascript
