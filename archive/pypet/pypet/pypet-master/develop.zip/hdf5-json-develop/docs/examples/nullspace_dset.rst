An HDF5 Dataset with an HDF5 NULL Dataspace
===========================================

.. literalinclude:: nullspace_dset.json
   :language: javascript
