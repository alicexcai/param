An "empty" HDF5 File
====================

.. literalinclude:: empty.json
   :language: javascript
