The "Classic"
=============

This example is equivalent to the one in section 4 of
`DDL in BNF for HDF5 <http://www.hdfgroup.org/HDF5/doc/ddl.html>`_.

.. literalinclude:: sample.json
   :language: javascript
