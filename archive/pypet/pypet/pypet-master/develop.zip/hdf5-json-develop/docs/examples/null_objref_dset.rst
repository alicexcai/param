An HDF5 Uninitialized HDF5 Object Reference
===========================================

.. literalinclude:: null_objref_dset.json
   :language: javascript
