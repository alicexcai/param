An HDF5 Array Datatype
======================

.. literalinclude:: array_dset.json
   :language: javascript
