An HDF5 Enumerated Datatype (Attribute)
=======================================

.. literalinclude:: enum_attr.json
   :language: javascript
