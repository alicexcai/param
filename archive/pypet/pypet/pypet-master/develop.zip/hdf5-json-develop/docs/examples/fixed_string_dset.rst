An HDF5 Fixed-Length String Datatype (Dataset)
==============================================

.. literalinclude:: fixed_string_dset.json
   :language: javascript
