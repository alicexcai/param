An HDF5 Object Reference Datatype (Attribute)
=============================================

.. literalinclude:: objref_attr.json
   :language: javascript
