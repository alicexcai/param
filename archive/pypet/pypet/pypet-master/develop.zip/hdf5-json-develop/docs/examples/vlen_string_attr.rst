An HDF5 variable-length String Datatype (Attribute)
===================================================

.. literalinclude:: vlen_string_attr.json
   :language: javascript
