An HDF5 Region Reference Datatype (Attribute)
=============================================

.. literalinclude:: regionref_attr.json
   :language: javascript
