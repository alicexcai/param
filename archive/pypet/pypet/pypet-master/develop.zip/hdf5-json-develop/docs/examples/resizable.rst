A resizable HDF5 Dataset
========================

.. literalinclude:: resizable.json
   :language: javascript
