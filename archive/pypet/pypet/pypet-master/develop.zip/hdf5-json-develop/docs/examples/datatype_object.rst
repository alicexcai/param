An HDF5 Datatype Object
=======================

.. literalinclude:: datatype_object.json
   :language: javascript
