HDF5 scalar Datasets and Attributes
===================================

.. literalinclude:: scalar.json
   :language: javascript
