An HDF5 variable-length Datatype (Dataset)
==========================================

.. literalinclude:: vlen_dset.json
   :language: javascript
