A few HDF5 Groups
=================

.. literalinclude:: tgroup.json
   :language: javascript
