Integration tests for hdf5-json
