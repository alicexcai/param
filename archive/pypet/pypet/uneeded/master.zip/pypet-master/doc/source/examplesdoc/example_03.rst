
.. _example-03:

=======================
Merging of Trajectories
=======================

Download: :download:`example_03_trajectory_merging.py <../../../examples/example_03_trajectory_merging.py>`

The code snippet below shows how to merge trajectories.


.. literalinclude:: ../../../examples/example_03_trajectory_merging.py