
.. _example-09:

=========================================================
Storing and Loading Large Results (or just parts of them)
=========================================================

Download: :download:`example_09_large_results.py <../../../examples/example_09_large_results.py>`

Want to know how to load large results in parts? See below:


.. literalinclude:: ../../../examples/example_09_large_results.py