
.. _example-18:

=================================
Large Explorations with Many Runs
=================================

Download: :download:`example_18_many_runs.py <../../../examples/example_18_many_runs.py>`

How to group many results into buckets


.. literalinclude:: ../../../examples/example_18_many_runs.py
