=============================
Annotations
=============================
.. autoclass:: pypet.annotations.Annotations
    :members:
