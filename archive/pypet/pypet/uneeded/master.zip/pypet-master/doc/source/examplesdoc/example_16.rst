
.. _example-16:

===========================
Lightweight Multiprocessing
===========================

Download: :download:`example_16_multiproc_context.py <../../../examples/example_16_multiproc_context.py>`

This example shows you how to use a :class:`~pypet.environment.MultiprocContext`.


.. literalinclude:: ../../../examples/example_16_multiproc_context.py