
.. _example-15:

=============================
Adding Data to the Trajectory
=============================

Download: :download:`example_15_more_ways_to_add_data.py <../../../examples/example_15_more_ways_to_add_data.py>`

Here are the different ways to add data to your :class:`~pypet.trajectory.Trajectory` container:


.. literalinclude:: ../../../examples/example_15_more_ways_to_add_data.py