
.. _example-08:

=============================
Using the f_find_idx Function
=============================

Download: :download:`example_08_f_find_idx.py <../../../examples/example_08_f_find_idx.py>`

Here you can see how you can search for particular parameter combinations and the corresponding
run indices using the :func:`~pypet.Trajectory.f_find_idx` function.


.. literalinclude:: ../../../examples/example_08_f_find_idx.py