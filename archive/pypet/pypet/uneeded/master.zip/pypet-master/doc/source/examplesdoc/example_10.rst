
.. _example-10:

=======================================
Accessing Results from All Runs at Once
=======================================

Download: :download:`example_10_get_items_from_all_runs.py <../../../examples/example_10_get_items_from_all_runs.py>`

Want to know how to access all data from results at once?
Check out :func:`~pypet.trajectory.Trajectory.f_get_from_runs` and the
code below:


.. literalinclude:: ../../../examples/example_10_get_items_from_all_runs.py