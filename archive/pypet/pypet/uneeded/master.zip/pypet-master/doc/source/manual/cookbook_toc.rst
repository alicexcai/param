
.. _cookbook:

==========================
Cookbook (Detailed Manual)
==========================

Here you can find some more detailed explanations of various concepts of *pypet*.


.. toctree::
      :maxdepth: 3
      :numbered:

      ../cookbook/trajectory
      ../cookbook/parameter
      ../cookbook/environment
      ../cookbook/brian.rst