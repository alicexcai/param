===================
*pypet* User Manual
===================

.. toctree::
   :maxdepth: 2

   introduction
   tutorial
   cookbook_toc
   examples_toc
   optimization_tips
   faqs