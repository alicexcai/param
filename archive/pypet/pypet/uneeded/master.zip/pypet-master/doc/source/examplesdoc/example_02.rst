
.. _example-02:

=======================================
Natural Naming, Storage and Loading
=======================================

Download: :download:`example_02_trajectory_access_and_storage.py <../../../examples/example_02_trajectory_access_and_storage.py>`

The following code snippet shows how natural naming works, and how you can store and load
a trajectory.

.. literalinclude:: ../../../examples/example_02_trajectory_access_and_storage.py

