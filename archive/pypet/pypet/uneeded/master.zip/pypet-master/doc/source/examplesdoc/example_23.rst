
.. _example-23:

====================
Short BRIAN2 Example
====================

Download: :download:`example_23_brian2_network.py <../../../examples/example_23_brian2_network.py>`

Find an example usage with BRIAN2_ below.

.. _BRIAN2: https://brian2.readthedocs.org/

.. literalinclude:: ../../../examples/example_23_brian2_network.py