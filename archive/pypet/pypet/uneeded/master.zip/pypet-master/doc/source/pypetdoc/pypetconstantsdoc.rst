=============================
Global Constants
=============================

Here you can find global constants. These constants define the data supported by the storage
service and the standard parameter, maximum length of comments, messages for storing and loading
etc.

.. automodule:: pypet.pypetconstants
    :members:
    :member-order: bysource



