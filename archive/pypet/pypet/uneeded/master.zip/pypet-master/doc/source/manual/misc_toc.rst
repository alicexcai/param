-------------
Miscellaneous
-------------

.. toctree::
   :maxdepth: 3

   misc
   changelog