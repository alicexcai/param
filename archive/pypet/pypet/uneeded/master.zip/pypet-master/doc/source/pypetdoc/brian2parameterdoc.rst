=======================================
Brian2 Parameters, Results and Monitors
=======================================

.. automodule:: pypet.brian2.parameter

---------------
Brian2Parameter
---------------

.. autoclass:: pypet.brian2.parameter.Brian2Parameter
    :members:

------------
Brian2Result
------------

.. autoclass:: pypet.brian2.parameter.Brian2Result
    :members:

-------------------
Brian2MonitorResult
-------------------

.. autoclass:: pypet.brian2.parameter.Brian2MonitorResult
    :members:
