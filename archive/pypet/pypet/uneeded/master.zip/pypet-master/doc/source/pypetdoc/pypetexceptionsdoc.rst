====================
Exceptions
====================

.. automodule:: pypet.pypetexceptions
    :members: