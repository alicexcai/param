
.. _example-14:

===========
Using Links
===========

Download: :download:`example_14_links.py <../../../examples/example_14_links.py>`

You can also link between different nodes of your :class:`~pypet.trajectory.Trajectory`:


.. literalinclude:: ../../../examples/example_14_links.py