.. toctree::
   :maxdepth: 2

   ../manual/manual_toc
   ../manual/misc_toc
   ../manual/code_toc
   latex_contact_license