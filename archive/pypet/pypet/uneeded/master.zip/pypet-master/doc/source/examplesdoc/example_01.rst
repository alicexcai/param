
.. _example-01:

===========
First Steps
===========

Download: :download:`example_01_first_steps.py <../../../examples/example_01_first_steps.py>`

This is a basic overview about the usage of the tool, nothing fancy.


.. literalinclude:: ../../../examples/example_01_first_steps.py