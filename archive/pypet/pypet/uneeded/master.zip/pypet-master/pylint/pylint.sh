#!/bin/bash
echo "Running pylint"
pylint --rcfile=.pylintrc ../pypet